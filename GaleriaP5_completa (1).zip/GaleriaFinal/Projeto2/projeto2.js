let angle = 0;
let grid = [];
let cols = 8;
let rows = 8;

function setup() {
  createCanvas(windowWidth, windowHeight);
  colorMode(HSB, 360, 100, 100, 100);
  rectMode(CENTER);
  noStroke();

  // Grelha de retângulos
  for (let i = 0; i < cols; i++) {
    for (let j = 0; j < rows; j++) {
      grid.push({ col: i, row: j, offset: random(TWO_PI) });
    }
  }
}

function draw() {
  background(220, 30, 8, 20);

  let cx = width / 2;
  let cy = height / 2;

  // Retângulos da grelha de fundo
  let cellW = min(width, height) * 0.08;
  let cellH = cellW;
  let startX = cx - (cols / 2) * cellW * 1.5;
  let startY = cy - (rows / 2) * cellH * 1.5;

  for (let cell of grid) {
    let x = startX + cell.col * cellW * 1.5;
    let y = startY + cell.row * cellH * 1.5;
    let pulse = sin(angle * 0.8 + cell.offset) * 0.5 + 0.5;
    let w = cellW * (0.4 + pulse * 0.4);
    let h = cellH * (0.4 + pulse * 0.4);
    fill(220, 70, 80, 15 + pulse * 15);
    push();
    translate(x, y);
    rotate(angle * 0.3 + cell.offset * 0.5);
    rect(0, 0, w, h, 4);
    pop();
  }

  // Retângulo principal
  push();
  translate(cx, cy);
  rotate(angle * 0.5);

  let w = 120 + sin(angle * 0.9) * 30;
  let h = 120 + cos(angle * 0.7) * 30;

  // Glow
  for (let i = 6; i > 0; i--) {
    fill(220, 80, 100, 6);
    rect(0, 0, w + i * 22, h + i * 22, 16 + i * 4);
  }

  // Corpo
  fill(220, 85, 90);
  rect(0, 0, w, h, 14);

  // Reflexo
  fill(220, 40, 100, 40);
  rect(-w * 0.15, -h * 0.28, w * 0.5, h * 0.25, 8);

  // Borda interior
  noFill();
  stroke(220, 60, 100, 30);
  strokeWeight(1.5);
  rect(0, 0, w - 10, h - 10, 10);
  noStroke();

  pop();

  // Linhas diagonais de fundo
  stroke(220, 50, 60, 6);
  strokeWeight(1);
  for (let i = -20; i < 40; i++) {
    let x1 = i * 60 + (frameCount * 0.3 % 60);
    line(x1, 0, x1 - height, height);
  }
  noStroke();

  angle += 0.035;
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}
