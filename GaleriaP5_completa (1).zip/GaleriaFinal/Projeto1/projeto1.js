let angle = 0;
let particles = [];

function setup() {
  createCanvas(windowWidth, windowHeight);
  colorMode(HSB, 360, 100, 100, 100);
  for (let i = 0; i < 60; i++) {
    particles.push(new Particle());
  }
}

function draw() {
  background(0, 0, 8, 25);

  // Círculos orbitais de fundo
  push();
  translate(width / 2, height / 2);
  noFill();
  for (let i = 1; i <= 4; i++) {
    stroke(0, 80, 100, 10);
    strokeWeight(1);
    ellipse(0, 0, i * 160, i * 160);
  }
  pop();

  // Partículas
  for (let p of particles) {
    p.update();
    p.draw();
  }

  // Círculo principal
  push();
  translate(width / 2, height / 2);
  
  let r = 80 + sin(angle * 0.7) * 20;

  // Glow
  noStroke();
  for (let i = 5; i > 0; i--) {
    fill(0, 90, 100, 8);
    ellipse(0, 0, r * 2 + i * 20, r * 2 + i * 20);
  }

  // Corpo
  fill(0, 85, 95);
  stroke(0, 60, 100, 60);
  strokeWeight(2);
  ellipse(0, 0, r * 2, r * 2);

  // Reflexo
  noStroke();
  fill(0, 30, 100, 50);
  ellipse(-r * 0.25, -r * 0.3, r * 0.5, r * 0.3);

  pop();

  angle += 0.04;
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}

class Particle {
  constructor() {
    this.reset();
  }

  reset() {
    this.x = random(width);
    this.y = random(height);
    this.size = random(2, 6);
    this.speed = random(0.3, 1.2);
    this.alpha = random(20, 60);
    this.hue = random(350, 380) % 360;
  }

  update() {
    this.y -= this.speed;
    this.x += sin(frameCount * 0.01 + this.y * 0.05) * 0.5;
    if (this.y < -10) this.reset();
  }

  draw() {
    noStroke();
    fill(this.hue, 70, 100, this.alpha);
    ellipse(this.x, this.y, this.size);
  }
}
